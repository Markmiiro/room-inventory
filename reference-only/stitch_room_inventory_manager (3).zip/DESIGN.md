---
name: Agri-Logic Management
colors:
  surface: '#f7faf5'
  surface-dim: '#d8dbd6'
  surface-bright: '#f7faf5'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f1f4ef'
  surface-container: '#ecefea'
  surface-container-high: '#e6e9e4'
  surface-container-highest: '#e0e3df'
  on-surface: '#191c1a'
  on-surface-variant: '#42493e'
  inverse-surface: '#2d312e'
  inverse-on-surface: '#eff2ed'
  outline: '#72796e'
  outline-variant: '#c2c9bb'
  surface-tint: '#3b6934'
  primary: '#154212'
  on-primary: '#ffffff'
  primary-container: '#2d5a27'
  on-primary-container: '#9dd090'
  inverse-primary: '#a1d494'
  secondary: '#3b6934'
  on-secondary: '#ffffff'
  secondary-container: '#b9eeab'
  on-secondary-container: '#3f6d38'
  tertiary: '#705d00'
  on-tertiary: '#ffffff'
  tertiary-container: '#c9a900'
  on-tertiary-container: '#4c3e00'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#bcf0ae'
  primary-fixed-dim: '#a1d494'
  on-primary-fixed: '#002201'
  on-primary-fixed-variant: '#23501e'
  secondary-fixed: '#bcf0ae'
  secondary-fixed-dim: '#a1d494'
  on-secondary-fixed: '#002201'
  on-secondary-fixed-variant: '#24501f'
  tertiary-fixed: '#ffe16d'
  tertiary-fixed-dim: '#e9c400'
  on-tertiary-fixed: '#221b00'
  on-tertiary-fixed-variant: '#544600'
  background: '#f7faf5'
  on-background: '#191c1a'
  surface-variant: '#e0e3df'
typography:
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 26px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  data-label:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.05em
  data-value:
    fontFamily: JetBrains Mono
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: 0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  margin: 16px
  gutter: 16px
  touch_target_min: 48px
  input_height: 56px
---

## Brand & Style
The design system focuses on "Modern Agritech" for small-scale mixed farming. The brand personality is utilitarian, high-contrast, and focused on operational efficiency. The goal is to reduce cognitive load for users working in outdoor or high-glare environments.

The design style is **Corporate / Modern** with a lean toward **Minimalism**. It prioritizes readability and physical interaction safety. Every UI decision is driven by utility: clear information hierarchy, generous touch targets for gloved or moving hands, and a strict color-coded logic that ensures safety and accuracy in livestock tracking.

## Colors
The palette is rooted in the natural farm environment but optimized for digital clarity.

- **Primary Green (#2D5A27):** Used for structural navigation, top bars, and indicating "active" or "selected" states.
- **Deep Green (#154212):** Reserved exclusively for high-level semantic headings to ground the page.
- **Primary Action Yellow (#FFD700):** This is the "Solar" highlight. It is used for the most important action on a screen. **Constraint:** Only one yellow button per screen. It must always use slate (#4A4A4A) text for contrast.
- **Problem Red (#BA1A1A):** Specifically for errors, alerts, or isolation states. Never used for decorative elements.
- **Background (#F4F7F2):** A slightly green-tinted off-white used to reduce screen glare during outdoor use.

## Typography
The system uses a dual-font approach. **Inter** handles all narrative and structural text, providing a neutral and highly legible sans-serif base. **JetBrains Mono** is utilized for "Hard Data"—room codes, ear tag numbers, animal counts, currency, and dates. This distinction ensures the user immediately recognizes variable data versus static interface labels.

- **Headcounts:** Must always be displayed as "Current of Total" (e.g., 45 of 53) using JetBrains Mono.
- **Labels:** Use `data-label` for field headers to create a "technical ledger" aesthetic.

## Layout & Spacing
The layout follows an **8px linear grid** to ensure mathematical consistency. 

- **Margins:** A standard 16px safe area is maintained on all mobile screens.
- **Touch Targets:** To accommodate use in the field, no interactive element should be smaller than 48px. Inputs are specifically oversized at 56px height to allow for easier tapping.
- **Responsive Behavior:** On desktop, cards arrange in a multi-column fluid grid. On mobile, cards stack vertically to maintain full-width readability of data strings.

## Elevation & Depth
Depth is signaled through **Tonal Layering** and subtle shadows.
- **Surface Level:** The background is #F4F7F2.
- **Object Level:** Cards and containers are #FFFFFF.
- **Shadows:** Use an 8% opacity soft shadow (0px 4px 12px rgba(0,0,0,0.08)) to lift cards from the background without creating visual clutter.
- **Active State:** Selected items use a 2px inside border of Primary Green (#2D5A27) rather than a heavy shadow.

## Shapes
The shape language is "Soft-Geometric." 
- **Buttons and Small Cards:** 8px radius.
- **Feature/Room Cards:** 16px radius for a more containerized, distinct look.
- **Chips:** Fully rounded (pill-shaped) to distinguish them from interactive buttons.
- **Isolation Marker:** Any room designated for isolation must include a 5px solid left border in Problem Red (#BA1A1A).

## Components

### Buttons
- **Primary Action:** Yellow (#FFD700) with Slate (#4A4A4A) text. Limit to one per view.
- **Secondary Action:** Primary Green (#2D5A27) with White text.
- **Tertiary/Ghost:** Slate text with an 8px radius border (#D1D1D1).

### Cards
- **Inventory Cards:** Must display the head count in the top right using JetBrains Mono. 
- **Isolation Cards:** Require a #BA1A1A 5px left-edge accent.

### Inputs & Selection
- **Text Inputs:** 56px height, 8px radius, #D1D1D1 border.
- **Checkboxes:** 24px x 24px minimum size for the hit box.
- **Status Indicators:** Never use color alone. An icon (e.g., a warning triangle) must accompany Problem Red text or backgrounds.

### Banners
- **Problem Banner:** Uses #FFDAD6 background with #BA1A1A text and a bold error icon. These are used for urgent health alerts or capacity overflows.